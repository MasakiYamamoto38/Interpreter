package newlang3;

//値タイプ列挙型 - ValueType
// 値の種類の数え上げ型定義
public enum ValueType {
	VOID,
	INTEGER,
	STRING,
	DOUBLE,
	BOOL,
}
