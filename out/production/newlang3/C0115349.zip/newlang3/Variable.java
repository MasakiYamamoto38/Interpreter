package newlang3;

public class Variable {
}
