package newlang3;

public class Function {
}
